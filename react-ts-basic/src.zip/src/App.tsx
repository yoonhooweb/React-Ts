import Header from "./components/Header";
import Home from "./components/Home";
import Footer from "./components/Footer";

export default function App() {
    const numberValue = 30;
    const stringValue = "스트링";
    const booleanValue = true;
    const array = [1,2,3,4];
    const object = {name : 'jo' , age : 20}
    const handleClick = ( ) => alert("안녕하세요")

    return (
        <>
            <Header />
            <Home 
                name="yoonhoo"
                age={20}
                numberValue = { numberValue }
                stringValue = { stringValue }
                booleanValue = { booleanValue }
                array = { array }
                object = {object}
                handleClick = {handleClick}
            />
            <Footer />
        </>
    );
}
