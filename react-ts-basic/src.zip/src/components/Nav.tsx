export default function Nav () {
  return (
    <>
      <h1>Nav Component</h1>
    </>
  );
}