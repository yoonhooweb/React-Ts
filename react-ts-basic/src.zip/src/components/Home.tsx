export default function Home(props : HomeProps){
	console.log(props)
    return (
        <>
            <h1>name : {props.name} </h1>
            <h1>age : {props.age}</h1>
        </>
    );
}
