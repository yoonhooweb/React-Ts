import Nav from './Nav'

export default function Header () {
  return (
    <>
      <h1>Header Component</h1>
      <Nav />
    </>
  );
}