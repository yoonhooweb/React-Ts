export default function Footer () {
  return (
    <>
      <h1>Footer Component</h1>
    </>
  );
}